import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.*;

/**
 * Write a description of class ImageInFrame here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */

public class ImageInFrame {
    private String path;
    public ImageInFrame(String name)
    {
        path = name;
        File file = new File(getPath());
         BufferedImage image;
        try{
        image = ImageIO.read(file);
        }
        catch (Exception E){System.out.println("Error"); 
            return;
        }
        JLabel label = new JLabel(new ImageIcon(image));
          JFrame f = new JFrame();
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.getContentPane().add(label);
        f.pack();
        f.setLocation(200,200);
        f.setVisible(true);
    }
    
    public String getPath()
    {
        return path;
    }
   
}

