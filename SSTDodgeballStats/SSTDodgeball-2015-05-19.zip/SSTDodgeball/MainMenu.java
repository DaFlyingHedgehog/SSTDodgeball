/**
*Text genereted by Simple GUI Extension for BlueJ
*/
import javax.swing.UIManager.LookAndFeelInfo;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;
import javax.swing.border.Border;
import javax.swing.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;



public class MainMenu extends JFrame {

	private JMenuBar menuBar;
	private JTextArea Title;
	private ImageInFrame mainPic;
	
	JPanel pan = new JPanel();
	

	//Constructor 
	public MainMenu(){
        
		this.setTitle("GUI_project");
		this.setSize(500,400);
		//menu generate method
		generateMenu();
		this.setJMenuBar(menuBar);
		
        //this.setJMenuBar(mainPic);
		//pane with null layout
		JPanel contentPane = new JPanel(null);
		contentPane.setPreferredSize(new Dimension(500,400));
		contentPane.setBackground(new Color(192,192,192));
        mainPic = new ImageInFrame("SSTDodge.jpg");

		Title = new JTextArea();
		Title.setBounds(149,11,131,40);
		Title.setBackground(new Color(255,255,255));
		Title.setForeground(new Color(0,0,0));
		Title.setEnabled(true);
		Title.setFont(new Font("sansserif",0,12));
		Title.setText("SST Dodgeball");
		Title.setBorder(BorderFactory.createBevelBorder(1));
		Title.setVisible(true);

		//adding components to contentPane panel
		contentPane.add(Title);

		//adding panel to JFrame and seting of window position and close operation
		this.add(contentPane);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLocationRelativeTo(null);
		this.pack();
		this.setVisible(true);
		
		JImageComponent ic = new JImageComponent(mainPic);
		imagePanel.add(ic);
		
	}
    
	
        
        
	//method for generate menu
	public void generateMenu(){
		menuBar = new JMenuBar();

		JMenu file = new JMenu("File");
		JMenu tools = new JMenu("Tools");
		JMenu help = new JMenu("Help");

		JMenuItem open = new JMenuItem("Open   ");
		JMenuItem save = new JMenuItem("Save   ");
		JMenuItem exit = new JMenuItem("Exit   ");
		JMenuItem preferences = new JMenuItem("Preferences   ");
		JMenuItem about = new JMenuItem("About   ");


		file.add(open);
		file.add(save);
		file.addSeparator();
		file.add(exit);
		tools.add(preferences);
		help.add(about);

		menuBar.add(file);
		menuBar.add(tools);
		menuBar.add(help);
	}

	 public static void main(String[] args){
		System.setProperty("swing.defaultlaf", "com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel");
		javax.swing.SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				new MainMenu();
			}
		});
	}

}